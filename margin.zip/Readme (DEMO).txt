This demo font is FREE FOR PERSONAL USE, but any donation are very appreciated

Paypal donation : https://paypal.me/rhesmannisa

Link to purchase full version and commercial license :
https://crmrkt.com/QPygmv?u=dharmas

If you need extended license or more :
dharmasahestya@gmail.com

Visit my store for more great fonts :
https://creativemarket.com/dharmas?u=dharmas

Visit my $1 deal :
https://thehungryjpeg.com/dharmas/

Thank you and enjoy :)

dharmas Std

